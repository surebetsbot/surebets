#!/bin/bash

echo "Opening environment"
source env/bin/activate
python3 WebAnalyzer.py
